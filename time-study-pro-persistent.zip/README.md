# Time Study Pro (Expo SDK 54)

This is an Expo SDK 54 app scaffold with multi-language support (English, Spanish, French) and persistence.

## Run with:
npm install
npx expo start
