import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import * as Localization from "react-native-localize";
import AsyncStorage from "@react-native-async-storage/async-storage";

const resources = {
  en: {
    translation: {
      welcome: "Time Study Pro - SDK54",
      change_language: "Change Language"
    }
  },
  es: {
    translation: {
      welcome: "Estudio de Tiempos - SDK54",
      change_language: "Cambiar Idioma"
    }
  },
  fr: {
    translation: {
      welcome: "Étude de Temps - SDK54",
      change_language: "Changer de Langue"
    }
  }
};

const fallback = { languageTag: "en", isRTL: false };

const loadLanguage = async () => {
  try {
    const storedLang = await AsyncStorage.getItem("appLanguage");
    if (storedLang) return storedLang;

    const { languageTag } =
      Localization.findBestAvailableLanguage(Object.keys(resources)) || fallback;
    return languageTag;
  } catch (e) {
    return "en";
  }
};

const initI18n = async () => {
  const lng = await loadLanguage();
  i18n.use(initReactI18next).init({
    compatibilityJSON: "v3",
    resources,
    lng,
    fallbackLng: "en",
    interpolation: {
      escapeValue: false
    }
  });
};

initI18n();

export const saveLanguage = async (lang) => {
  try {
    await AsyncStorage.setItem("appLanguage", lang);
    i18n.changeLanguage(lang);
  } catch (e) {
    console.error("Failed to save language", e);
  }
};

export default i18n;
